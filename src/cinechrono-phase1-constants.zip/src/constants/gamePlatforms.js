// ゲームプラットフォームの定義
export const gamePlatforms = [
  { id: 'ps5', name: 'PS5' },
  { id: 'ps4', name: 'PS4' },
  { id: 'switch', name: 'Nintendo Switch' },
  { id: 'pc', name: 'PC' },
  { id: 'xbox', name: 'Xbox' },
];
