// ユーティリティ関数をまとめてエクスポート
export { parseYear, getCentury, detectMainEra } from './parseYear';
export { getHistoryCategories, hasHistoryCategory } from './historyCategories';
